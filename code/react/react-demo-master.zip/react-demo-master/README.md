## react-demo

- 1.npm i
- 2.npm run start
- 3.http://localhost:3000/
