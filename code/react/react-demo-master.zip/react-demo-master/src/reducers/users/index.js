import Users from './Users'
export default {
    userStore:Users
};